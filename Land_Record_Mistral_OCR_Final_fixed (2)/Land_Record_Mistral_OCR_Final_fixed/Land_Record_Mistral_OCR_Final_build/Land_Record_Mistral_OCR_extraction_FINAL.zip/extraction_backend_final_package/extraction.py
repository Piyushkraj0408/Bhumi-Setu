"""Land-record field extraction for normalized/raw Mistral OCR output.

The extractor accepts both:
1. normalized pages containing ``blocks``/``tables``; and
2. lightweight pages containing ``index`` + ``markdown``/``text``.

It maps OCR evidence into the canonical land-record fields without inventing
values. Evidence, bbox and OCR confidence are retained whenever Mistral
provided them.
"""
from __future__ import annotations

import re
from typing import Any, Iterable, Optional

_FIELD_ALIASES = {
    "owner_name": ["नाम", "खातेदार", "स्वामी", "owner", "owner name"],
    "relative_name": ["पिता/पति", "पिता", "पिता का नाम", "पति", "पुत्र", "पुत्री", "पत्नी", "father", "father name", "husband", "husband name"],
    "village": ["ग्राम", "गांव", "गाँव", "village"],
    "tehsil": ["तहसील/प्रखंड", "तहसील", "प्रखंड", "tehsil"],
    "district": ["जिला", "district"],
    "state": ["राज्य", "state"],
    "khata_number": ["खाता संख्या", "खाता सं", "खाता नं", "खाता", "khata no", "khata"],
    "khasra_number": ["खेसरा संख्या", "खेसरा सं", "खेसरा", "खसरा संख्या", "खसरा", "गाटा संख्या", "गाटा", "khasra", "survey"],
    "plot_number": ["प्लॉट संख्या", "प्लॉट", "प्लाट", "plot no", "plot"],
    "area": ["रकवा", "रकबा", "क्षेत्रफल", "area"],
    "mutation_number": ["दाखिल खारिज", "नामांतरण", "म्यूटेशन", "mutation"],
    "registration_number": ["पंजीकरण", "रजिस्ट्रेशन", "registration"],
    "record_year": ["रिकॉर्ड वर्ष", "अभिलेख वर्ष", "वर्ष", "साल", "record year"],
    "land_classification": ["भूमि वर्गीकरण", "भूमि की किस्म", "वर्गीकरण", "classification"],
    "ownership_type": ["स्वामित्व प्रकार", "ownership type"],
    "police_station": ["थाना", "थाना का नाम", "police station"],
    "thana_number": ["थाना संख्या", "थाना सं", "थाना नं"],
}

_NUMBER_FIELDS = {"khata_number", "khasra_number", "plot_number", "mutation_number", "registration_number", "record_year", "thana_number"}
_REVIEW_THRESHOLD = 0.70
_DIGITS = str.maketrans("०१२३४५६७८९", "0123456789")


def _clean(value: Any) -> str:
    if value is None:
        return ""
    value = str(value).replace("\u200b", "").replace("\ufeff", "")
    return re.sub(r"\s+", " ", value).strip()


def _norm(value: Any) -> str:
    return _clean(value).lower().replace("ः", ":")


def _page_number(page: dict[str, Any]) -> int:
    return int(page.get("page_number", page.get("index", 0) + 1))


def _page_text(page: dict[str, Any]) -> str:
    return _clean(page.get("markdown") or page.get("text") or "")


def _synthetic_block(text: str) -> dict[str, Any]:
    return {"type": "text", "text": text, "bbox": None, "confidence": None, "min_confidence": None}


def _iter_text_blocks(pages: list[dict[str, Any]]) -> Iterable[tuple[int, dict[str, Any]]]:
    for page in pages:
        page_no = _page_number(page)
        blocks = page.get("blocks") or []
        emitted = False
        for block in blocks:
            if not isinstance(block, dict) or block.get("type") in {"image", "table"}:
                continue
            text = _clean(block.get("text", block.get("content", "")))
            if text:
                emitted = True
                yield page_no, block
        # Compatibility with simple tests/normalizers that expose only markdown/text.
        if not emitted:
            raw = page.get("markdown") or page.get("text") or ""
            for line in str(raw).splitlines():
                line = _clean(line)
                if line and "|" not in line and not line.startswith("![") and not line.startswith("[tbl-"):
                    yield page_no, _synthetic_block(line)


def _iter_tables(pages: list[dict[str, Any]]) -> Iterable[tuple[int, dict[str, Any], dict[str, Any]]]:
    for page in pages:
        page_no = _page_number(page)
        tables = page.get("tables") or []
        table_blocks = [b for b in page.get("blocks") or [] if isinstance(b, dict) and b.get("type") == "table"]
        for table in tables:
            if not isinstance(table, dict):
                continue
            content = table.get("content") or ""
            if not _clean(content):
                continue
            block = None
            tid = table.get("id")
            if tid:
                block = next((b for b in table_blocks if b.get("table_id") == tid), None)
            if block is None and len(table_blocks) == 1:
                block = table_blocks[0]
            if block is None:
                block = _synthetic_block(content)
                block["type"] = "table"
            yield page_no, table, block


def _evidence(page: int, block: dict[str, Any], source: str, text: Optional[str] = None) -> dict[str, Any]:
    scores = block.get("confidence_scores") or {}
    return {
        "page": page,
        "bbox": block.get("bbox"),
        "source": source,
        "text": _clean(text if text is not None else block.get("text", block.get("content", ""))),
        "ocr_confidence": block.get("confidence", scores.get("average_content_confidence_score")),
        "min_ocr_confidence": block.get("min_confidence", scores.get("minimum_content_confidence_score")),
        "block_type_confidence": block.get("block_type_confidence", scores.get("block_type_confidence_score")),
    }


def _make_field(value: Any, page: int, block: Optional[dict[str, Any]], source: str, extraction_confidence: float, evidence_text: Optional[str] = None) -> dict[str, Any]:
    raw_conf = None if block is None else block.get("confidence", (block.get("confidence_scores") or {}).get("average_content_confidence_score"))
    ocr_conf = float(raw_conf) if raw_conf is not None else None
    final = extraction_confidence if ocr_conf is None else round(0.65 * ocr_conf + 0.35 * extraction_confidence, 4)
    item = {
        "value": value,
        "page": page,
        "ocr_confidence": round(ocr_conf, 4) if ocr_conf is not None else None,
        "extraction_confidence": round(extraction_confidence, 4),
        "final_confidence": final,
        "review_required": final < _REVIEW_THRESHOLD,
        "evidence": [_evidence(page, block or _synthetic_block(evidence_text or str(value)), source, evidence_text or None)],
    }
    return item


def _extract_number(value: str) -> Optional[str]:
    value = _clean(value)
    m = re.search(r"(?<![\d०-९])[\d०-९]+(?:[/-][\d०-९]+)?[A-Za-z]?", value)
    return m.group(0).translate(_DIGITS) if m else None


def _extract_area(value: str) -> tuple[Optional[str], Optional[str]]:
    value = _clean(value)
    m = re.search(r"([\d०-९]+(?:[.,][\d०-९]+)?)\s*(हेक्टेयर|हे\.?|ha|hectare|acre|एकड़|डि०|डि\.?|डेसिमल)?", value, re.I)
    if not m:
        return None, None
    number = m.group(1).replace(",", ".").translate(_DIGITS)
    return number, _clean(m.group(2)) or None


def _parse_markdown_table(content: str) -> tuple[list[str], list[list[str]]]:
    rows = []
    for line in str(content).splitlines():
        if "|" not in line:
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        rows.append(cells)
    if len(rows) < 2:
        return [], []
    header = rows[0]
    data = []
    for row in rows[1:]:
        if all(re.fullmatch(r":?-{3,}:?", c.replace(" ", "")) for c in row):
            continue
        row = row + [""] * max(0, len(header) - len(row))
        data.append(row[:len(header)])
    return header, data


def _table_unit(content: str, index: int) -> Optional[str]:
    rows = [[c.strip() for c in line.strip().strip("|").split("|")] for line in str(content).splitlines() if "|" in line]
    if len(rows) < 3:
        return None
    sub = rows[2]
    for i in (index + 1, index):
        if i < len(sub) and _clean(sub[i]) and not re.fullmatch(r":?-{3,}:?", _clean(sub[i])):
            return _clean(sub[i])
    return None


def _extract_owner_relative(page: int, block: dict[str, Any]) -> dict[str, dict[str, Any]]:
    text = _clean(block.get("text", ""))
    if not text:
        return {}
    result = {}
    # Common single-line form: नाम अजय सिंह पिता/पति स्व० गोला सिंह
    m = re.search(r"नाम\s*[:：]?\s*(.+?)\s+(पिता/पति|पिता|पति)\s*[:：]?\s*(.+)$", text)
    if m:
        owner = _clean(m.group(1))
        relation = _clean(m.group(2))
        relative = re.sub(r"^(?:स्व\s*[०\.]?|स्वर्गीय)\s*", "", _clean(m.group(3))).strip()
        result["owner_name"] = _make_field(owner, page, block, "text_block", 0.94, text)
        result["relation"] = _make_field(relation, page, block, "text_block", 0.96, text)
        result["relative_name"] = _make_field(relative, page, block, "text_block", 0.92, text)
        return result

    # Label/value forms: नाम: राम प्रसाद, पिता: श्याम प्रसाद
    name = re.search(r"(?:^|\s)नाम\s*[:：]\s*(.+)$", text)
    if name:
        result["owner_name"] = _make_field(_clean(name.group(1)), page, block, "text_block", 0.94, text)
    rel = re.search(r"(?:^|\s)(पिता/पति|पिता|पति)\s*[:：]\s*(.+)$", text)
    if rel:
        relative = re.sub(r"^(?:स्व\s*[०\.]?|स्वर्गीय)\s*", "", _clean(rel.group(2))).strip()
        result["relation"] = _make_field(_clean(rel.group(1)), page, block, "text_block", 0.95, text)
        result["relative_name"] = _make_field(relative, page, block, "text_block", 0.92, text)
    return result


def _extract_location(page: int, block: dict[str, Any]) -> dict[str, dict[str, Any]]:
    text = _clean(block.get("text", ""))
    result = {}
    m = re.search(r"(?:^|\s)ग्राम\s*[:：]?\s*(.+?)(?=\s+थाना\b|\s+जिला\b|$)", text)
    if m:
        result["village"] = _make_field(_clean(m.group(1)), page, block, "text_block", 0.92, text)
    m = re.search(r"थाना\s*[:：]?\s*(.+?)(?=\s+जिला(?:\s|$)|$)", text)
    if m:
        result["police_station"] = _make_field(_clean(m.group(1)), page, block, "text_block", 0.92, text)
    m = re.search(r"जिला\s*[:：]?\s*(.+)$", text)
    if m:
        result["district"] = _make_field(_clean(m.group(1)), page, block, "text_block", 0.94, text)
    return result


def _extract_generic(page: int, block: dict[str, Any], existing: set[str]) -> dict[str, dict[str, Any]]:
    text = _clean(block.get("text", ""))
    result = {}
    if not text:
        return result
    for field, aliases in _FIELD_ALIASES.items():
        if field in existing or field in {"owner_name", "relative_name", "relation", "village", "district", "police_station"}:
            continue
        for alias in sorted(aliases, key=len, reverse=True):
            m = re.search(re.escape(alias) + r"\s*[:：\-]?\s*(.+)$", text, re.I)
            if not m:
                continue
            value = _clean(m.group(1))
            if field in _NUMBER_FIELDS:
                value = _extract_number(value)
                if not value:
                    continue
                conf = 0.90
            elif field == "area":
                number, unit = _extract_area(value)
                if not number:
                    continue
                value, conf = {"value": number, "unit": unit}, 0.90
            else:
                conf = 0.82
            result[field] = _make_field(value, page, block, "text_block", conf, text)
            break
    return result


def _extract_table(page: int, table: dict[str, Any], block: dict[str, Any]) -> dict[str, dict[str, Any]]:
    header, rows = _parse_markdown_table(table.get("content", ""))
    if not header or not rows:
        return {}
    normalized = [_norm(h) for h in header]
    col: dict[str, int] = {}
    for i, h in enumerate(normalized):
        if "ग्राम" in h and "थाना" in h:
            col["village_thana"] = i
        elif "खाता" in h:
            col["khata_number"] = i
        elif "खेसरा" in h or "खसरा" in h:
            col["khasra_number"] = i
        elif "रकवा" in h or "रकबा" in h or "area" in h:
            col["area"] = i
    # In Mistral's two-level header, रकवा is followed by the actual numeric column.
    if "area" in col and col["area"] + 1 < len(header) and not _clean(rows[-1][col["area"]]):
        col["area"] += 1
    row = rows[-1]
    def cell(name: str) -> str:
        i = col.get(name)
        return _clean(row[i]) if i is not None and i < len(row) else ""
    result = {}
    vt = cell("village_thana")
    if vt:
        m = re.match(r"(.+?)(?:,\s*थाना\s*(?:सं(?:ख्या|०|\.)?\s*[-:]?\s*)?(\d+))?$", vt)
        if m:
            village = _clean(m.group(1))
            if village:
                result["village"] = _make_field(village, page, block, "table", 0.95, vt)
            if m.group(2):
                result["thana_number"] = _make_field(m.group(2), page, block, "table", 0.97, vt)
    khata = _extract_number(cell("khata_number"))
    if khata:
        result["khata_number"] = _make_field(khata, page, block, "table", 0.98, cell("khata_number"))
    khasra = _extract_number(cell("khasra_number"))
    if khasra:
        result["khasra_number"] = _make_field(khasra, page, block, "table", 0.98, cell("khasra_number"))
    area_raw = cell("area")
    if area_raw:
        number, unit = _extract_area(area_raw)
        if number and not unit:
            unit = _table_unit(table.get("content", ""), col["area"])
        if number:
            result["area"] = _make_field({"value": number, "unit": unit}, page, block, "table", 0.97, area_raw)
    return result


def extract_fields(pages: list[dict[str, Any]]) -> dict[str, Any]:
    """Extract evidence-backed canonical land-record fields from OCR pages."""
    fields: dict[str, dict[str, Any]] = {}
    blocks = list(_iter_text_blocks(pages))

    # First pass: strongest structure-specific fields.
    for page, block in blocks:
        for key, value in {**_extract_owner_relative(page, block), **_extract_location(page, block)}.items():
            if key not in fields:
                fields[key] = value

    # Generic label/value extraction.
    for page, block in blocks:
        for key, value in _extract_generic(page, block, set(fields)).items():
            fields.setdefault(key, value)

    # Tables override numeric fields because column semantics are stronger.
    for page, table, block in _iter_tables(pages):
        for key, value in _extract_table(page, table, block).items():
            fields[key] = value

    return fields


__all__ = ["extract_fields"]
