import json
import sys
sys.path.insert(0, "/mnt/data")
from extraction import extract_fields


def test_land_record2_mistral_json():
    with open("/mnt/data/Pasted code(2).json", encoding="utf-8") as f:
        payload = json.load(f)

    fields = extract_fields(payload["pages"])

    assert fields["owner_name"]["value"] == "अजय सिंह"
    assert fields["relative_name"]["value"] == "गोला सिंह"
    assert fields["relation"]["value"] == "पिता/पति"
    assert fields["village"]["value"] == "आशोपुर"
    assert fields["police_station"]["value"] == "दानापुर"
    assert fields["district"]["value"] == "पटना"
    assert fields["thana_number"]["value"] == "34"
    assert fields["khata_number"]["value"] == "19"
    assert fields["khasra_number"]["value"] == "156"
    assert fields["area"]["value"] == {"value": "5.75", "unit": "डि०"}

    for field in fields.values():
        assert "evidence" in field
        assert "final_confidence" in field
        assert field["evidence"]
