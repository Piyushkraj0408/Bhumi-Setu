"""Land-record field extraction from normalized Mistral OCR pages.

Consumes the normalized page structure produced by ``normalizer.normalize_pages``
and understands Mistral OCR's text blocks and markdown tables.  The extractor
keeps source evidence (page, bbox, source text, block/table confidence) with
each field so the backend can persist an auditable result.
"""

from __future__ import annotations

import re
from typing import Any, Iterable, Optional


# Canonical field names from the approved SRS, plus two useful document fields
# that are present in the sample but are not part of the original SRS list.
FIELD_ALIASES = {
    "owner_name": ["नाम", "नामधारी", "खातेदार", "स्वामी", "owner", "owner name"],
    "relative_name": [
        "पिता/पति", "पिता", "पिता का नाम", "पति", "पुत्र", "पुत्री", "पत्नी",
        "father", "father name", "husband", "husband name",
    ],
    "village": ["ग्राम", "गांव", "गाँव", "village"],
    "tehsil": ["तहसील/प्रखंड", "तहसील", "प्रखंड", "tehsil"],
    "district": ["जिला", "district"],
    "state": ["राज्य", "state"],
    "khata_number": ["खाता संख्या", "खाता सं", "खाता नं", "खाता", "khata no", "khata"],
    "khasra_number": ["खेसरा संख्या", "खेसरा सं", "खेसरा", "खसरा संख्या", "खसरा", "गाटा संख्या", "गाटा", "khasra", "survey"],
    "plot_number": ["प्लॉट संख्या", "प्लॉट", "प्लाट", "plot no", "plot"],
    "area": ["रकवा", "रकबा", "क्षेत्रफल", "area"],
    "mutation_number": ["दाखिल खारिज", "नामांतरण", "म्यूटेशन", "mutation"],
    "registration_number": ["पंजीकरण", "रजिस्ट्रेशन", "registration"],
    "record_year": ["रिकॉर्ड वर्ष", "अभिलेख वर्ष", "वर्ष", "साल", "record year"],
    "land_classification": ["भूमि वर्गीकरण", "भूमि की किस्म", "वर्गीकरण", "classification"],
    "ownership_type": ["स्वामित्व प्रकार", "ownership type"],
    "police_station": ["थाना", "थाना का नाम", "police station"],
    "thana_number": ["थाना संख्या", "थाना सं", "थाना नं"],
}

_NUMBER_FIELDS = {
    "khata_number", "khasra_number", "plot_number", "mutation_number",
    "registration_number", "record_year", "thana_number",
}

_REVIEW_THRESHOLD = 0.70


def _clean(text: Any) -> str:
    if text is None:
        return ""
    text = str(text).replace("\u200b", "").replace("\ufeff", "")
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _norm_label(text: str) -> str:
    text = _clean(text).lower()
    text = text.replace("ः", ":")
    return text


def _block_evidence(page_number: int, block: dict[str, Any], source: str) -> dict[str, Any]:
    bbox = block.get("bbox")
    if bbox is None and all(k in block for k in ("top_left_x", "top_left_y", "bottom_right_x", "bottom_right_y")):
        bbox = [block["top_left_x"], block["top_left_y"], block["bottom_right_x"], block["bottom_right_y"]]
    return {
        "page": page_number,
        "bbox": bbox,
        "source": source,
        "text": _clean(block.get("text", block.get("content", ""))),
        "ocr_confidence": block.get("confidence", (block.get("confidence_scores") or {}).get("average_content_confidence_score")),
        "min_ocr_confidence": block.get("min_confidence", (block.get("confidence_scores") or {}).get("minimum_content_confidence_score")),
        "block_type_confidence": block.get("block_type_confidence", (block.get("confidence_scores") or {}).get("block_type_confidence_score")),
    }


def _make_field(
    value: Any,
    page: int,
    *,
    block: Optional[dict[str, Any]] = None,
    source: str = "text_block",
    extraction_confidence: float = 0.80,
    evidence_text: Optional[str] = None,
    extra: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """Create a canonical field object without inventing confidence."""
    block_conf = None if block is None else block.get("confidence", (block.get("confidence_scores") or {}).get("average_content_confidence_score"))
    if block_conf is None:
        ocr_confidence = 0.0
    else:
        ocr_confidence = float(block_conf)

    # Evidence-based score. Extraction confidence represents how strongly the
    # label/pattern/layout supports the value; it is not the OCR score.
    final = round((0.65 * ocr_confidence) + (0.35 * extraction_confidence), 4)

    item: dict[str, Any] = {
        "value": value,
        "page": page,
        "ocr_confidence": round(ocr_confidence, 4),
        "extraction_confidence": round(extraction_confidence, 4),
        "final_confidence": final,
        "review_required": final < _REVIEW_THRESHOLD,
        "evidence": [],
    }

    if block is not None:
        ev = _block_evidence(page, block, source)
        if evidence_text is not None:
            ev["text"] = evidence_text
        item["evidence"].append(ev)

    if extra:
        item.update(extra)

    return item


def _iter_blocks(pages: list[dict[str, Any]]) -> Iterable[tuple[int, dict[str, Any]]]:
    for page in pages:
        page_number = int(page.get("page_number", page.get("index", 0) + 1))
        for block in page.get("blocks") or []:
            if isinstance(block, dict):
                yield page_number, block


def _text_blocks(pages: list[dict[str, Any]]) -> list[tuple[int, dict[str, Any]]]:
    result = []
    for page_no, block in _iter_blocks(pages):
        text = _clean(block.get("text", block.get("content", "")))
        if text and block.get("type") not in {"image", "table"}:
            result.append((page_no, block))
    return result


def _page_tables(pages: list[dict[str, Any]]) -> Iterable[tuple[int, dict[str, Any], dict[str, Any]]]:
    """Yield (page_number, table, synthetic_block) for Mistral tables."""
    for page in pages:
        page_no = int(page.get("page_number", page.get("index", 0) + 1))
        for table in page.get("tables") or []:
            if not isinstance(table, dict):
                continue
            content = _clean(table.get("content"))
            if not content:
                continue
            table_blocks = [b for b in page.get("blocks") or [] if b.get("type") == "table"]
            table_block = next(
                (b for b in table_blocks if table.get("id") and b.get("table_id") == table.get("id")),
                None,
            )
            # Canonical JSON may omit table_id even though the page has exactly
            # one table block. Fall back to that block so bbox/confidence are kept.
            if table_block is None and len(table_blocks) == 1:
                table_block = table_blocks[0]
            if table_block is None:
                table_block = {"type": "table", "bbox": None, "confidence": None,
                               "min_confidence": None, "block_type_confidence": None,
                               "text": content}
            yield page_no, table, table_block


def _split_md_row(line: str) -> list[str]:
    line = line.strip().strip("|")
    return [c.strip() for c in line.split("|")]


def _parse_markdown_table(content: str) -> tuple[list[str], list[list[str]]]:
    rows = [_split_md_row(x) for x in content.splitlines() if "|" in x]
    if len(rows) < 2:
        return [], []
    header = rows[0]
    data_rows = []
    for row in rows[1:]:
        if all(re.fullmatch(r":?-{3,}:?", c.replace(" ", "")) for c in row):
            continue
        if len(row) < len(header):
            row += [""] * (len(header) - len(row))
        data_rows.append(row[:len(header)])
    return header, data_rows


def _first_nonempty(cells: list[str]) -> Optional[str]:
    for c in cells:
        c = _clean(c)
        if c:
            return c
    return None


def _extract_number(value: str) -> Optional[str]:
    # Handles ASCII/Devanagari digits, 124/2A, 41-2 and plain integers.
    # Labels such as "संख्या" are not themselves considered values.
    value = _clean(value)
    m = re.search(r"(?<![\d०-९])[\d०-९]+(?:[/-][\d०-९]+)?[A-Za-z]?", value)
    if not m:
        return None
    return m.group(0).translate(str.maketrans("०१२३४५६७८९", "0123456789"))


def _extract_area(value: str) -> tuple[Optional[str], Optional[str]]:
    value = _clean(value)
    m = re.search(r"(\d+(?:[.,]\d+)?)\s*(हेक्टेयर|हे\.?|ha|hectare|acre|एकड़|डि०|डि\.?|डेसिमल)?", value, re.I)
    if not m:
        return None, None
    number = m.group(1).replace(",", ".").translate(str.maketrans("०१२३४५६७८९", "0123456789"))
    unit = _clean(m.group(2)) or None
    return number, unit


def _label_value(line: str, aliases: list[str]) -> Optional[str]:
    """Extract value after a label, including labels without ':' separators."""
    line_clean = _clean(line)
    low = _norm_label(line_clean)
    aliases_sorted = sorted(aliases, key=len, reverse=True)

    for alias in aliases_sorted:
        a = _norm_label(alias)
        pos = low.find(a)
        if pos < 0:
            continue
        tail = line_clean[pos + len(alias):]
        tail = re.sub(r"^[\s:：\-–—]+", "", tail).strip()
        if tail:
            return tail
    return None


def _extract_owner_and_relative(page_no: int, block: dict[str, Any]) -> dict[str, dict[str, Any]]:
    text = _clean(block.get("text", block.get("content", "")))
    if not text:
        return {}

    # Handles the exact Mistral structure seen in land_record2.pdf:
    # "नाम अजय सिंह    पिता/पति स्व० गोला सिंह"
    m = re.search(
        r"नाम\s+(.+?)\s+(?:पिता/पति|पिता|पति)\s+(.+)$",
        text,
        re.I,
    )
    if not m:
        return {}

    owner = _clean(m.group(1))
    relative = _clean(m.group(2))
    relative = re.sub(r"^(?:स्व(?:०|\.)?|स्वर्गीय)\s*", "", relative).strip()
    relation_match = re.search(r"(पिता/पति|पिता|पति)", text)
    relation = relation_match.group(1) if relation_match else None

    result = {
        "owner_name": _make_field(
            owner, page_no, block=block, source="text_block",
            extraction_confidence=0.94, evidence_text=text,
        ),
        "relative_name": _make_field(
            relative, page_no, block=block, source="text_block",
            extraction_confidence=0.92, evidence_text=text,
        ),
    }
    if relation:
        result["relation"] = _make_field(
            relation, page_no, block=block, source="text_block",
            extraction_confidence=0.96, evidence_text=text,
        )
    return result


def _extract_header_line_fields(page_no: int, block: dict[str, Any]) -> dict[str, dict[str, Any]]:
    text = _clean(block.get("text", block.get("content", "")))
    result: dict[str, dict[str, Any]] = {}
    if not text:
        return result

    # Village: "ग्राम आशोपुर"
    m = re.search(r"(?:^|\s)ग्राम\s+([^\s]+(?:\s+[^\s]+)*)", text)
    if m:
        village = _clean(m.group(1))
        result["village"] = _make_field(village, page_no, block=block,
                                         extraction_confidence=0.92, evidence_text=text)

    # Police station and district can occur on the same line.
    m = re.search(r"थाना\s+(.+?)(?:\s+जिला\s+(.+))?$", text)
    if m:
        police = _clean(m.group(1))
        district = _clean(m.group(2)) if m.group(2) else None
        if police:
            result["police_station"] = _make_field(
                police, page_no, block=block, extraction_confidence=0.92, evidence_text=text
            )
        if district:
            result["district"] = _make_field(
                district, page_no, block=block, extraction_confidence=0.94, evidence_text=text
            )
    return result


def _table_subheader_unit(content: str, area_index: int) -> Optional[str]:
    """Read a unit from Mistral's optional second-level table header."""
    rows = [_split_md_row(x) for x in content.splitlines() if "|" in x]
    if len(rows) < 3:
        return None
    # rows[1] is normally the markdown separator; rows[2] is the subheader.
    subheader = rows[2]
    # If the parent रकवा header is followed by an empty header cell, the
    # numeric value may belong to the following sub-column (e.g. "एकड़ | डि०").
    # Prefer that following sub-column when it contains a unit.
    if area_index + 1 < len(subheader):
        unit = _clean(subheader[area_index + 1])
        if unit and not re.fullmatch(r"[:\-]+", unit):
            return unit
    if area_index < len(subheader):
        unit = _clean(subheader[area_index])
        if unit and not re.fullmatch(r"[:\-]+", unit):
            return unit
    return None


def _extract_table_fields(page_no: int, table: dict[str, Any], block: dict[str, Any]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    header, rows = _parse_markdown_table(table.get("content", ""))
    if not header or not rows:
        return result

    # The sample has a two-level area header. We preserve the actual unit found
    # in the data cell rather than guessing a conversion.
    normalized_headers = [_norm_label(h) for h in header]
    col = {}
    for i, h in enumerate(normalized_headers):
        if "ग्राम" in h and "थाना" in h:
            col["village_thana"] = i
        elif "तौजी" in h:
            col["tauzi"] = i
        elif "खाता" in h:
            col["khata_number"] = i
        elif "खेसरा" in h or "खसरा" in h:
            col["khasra_number"] = i
        elif "रकवा" in h or "रकबा" in h or "area" in h:
            col["area"] = i

    # Mistral may emit a second header row for sub-columns (e.g. "एकड़ | डि०")
    # while the first header cell for the area column is followed by an empty
    # header. In that case the last non-semantic column is the area value.
    if "area" not in col and "रकवा" in normalized_headers:
        r_idx = normalized_headers.index("रकवा")
        if r_idx + 1 < len(header):
            col["area"] = r_idx + 1

    row = rows[-1]
    def cell(name: str) -> str:
        i = col.get(name)
        value = _clean(row[i]) if i is not None and i < len(row) else ""
        # In a two-level Mistral table header, "रकवा" can occupy a parent
        # column while the actual numeric value is in the following sub-column.
        if name == "area" and not value and i is not None and i + 1 < len(row):
            value = _clean(row[i + 1])
        return value

    village_thana = cell("village_thana")
    if village_thana:
        m = re.match(r"(.+?)(?:,\s*थाना\s*(?:सं(?:ख्या|०|\.)?\s*[-:]?\s*)?(\d+))?$", village_thana)
        if m:
            village = _clean(m.group(1))
            if village:
                result["village"] = _make_field(
                    village, page_no, block=block, source="table", extraction_confidence=0.95,
                    evidence_text=village_thana,
                )
            if m.group(2):
                result["thana_number"] = _make_field(
                    m.group(2), page_no, block=block, source="table", extraction_confidence=0.97,
                    evidence_text=village_thana,
                )

    khata = _extract_number(cell("khata_number"))
    if khata:
        result["khata_number"] = _make_field(
            khata, page_no, block=block, source="table", extraction_confidence=0.98,
            evidence_text=cell("khata_number"),
        )

    khasra = _extract_number(cell("khasra_number"))
    if khasra:
        result["khasra_number"] = _make_field(
            khasra, page_no, block=block, source="table", extraction_confidence=0.98,
            evidence_text=cell("khasra_number"),
        )

    area_raw = cell("area")
    if area_raw:
        value, unit = _extract_area(area_raw)
        if value and not unit:
            area_index = col.get("area")
            if area_index is not None:
                unit = _table_subheader_unit(table.get("content", ""), area_index)
        if value:
            result["area"] = _make_field(
                {"value": value, "unit": unit}, page_no, block=block, source="table",
                extraction_confidence=0.97, evidence_text=area_raw,
            )

    return result


def extract_fields(pages: list[dict[str, Any]]) -> dict[str, Any]:
    """Extract canonical land-record fields from normalized Mistral OCR pages.

    The function deliberately does not invent absent fields.  It searches both
    Mistral text blocks and markdown tables, preferring structured/table evidence
    for numeric land identifiers and label/value text for owner/location fields.
    """
    fields: dict[str, dict[str, Any]] = {}
    blocks = _text_blocks(pages)

    # 1) Owner + relation + relative name from the common Hindi form layout.
    for page_no, block in blocks:
        found = _extract_owner_and_relative(page_no, block)
        for key, value in found.items():
            if key not in fields:
                fields[key] = value

    # 2) Simple location lines such as ग्राम/थाना/जिला.
    for page_no, block in blocks:
        found = _extract_header_line_fields(page_no, block)
        for key, value in found.items():
            if key not in fields:
                fields[key] = value

    # 3) Generic labeled fields. Skip fields already obtained from stronger
    # structure-specific parsers.
    for page_no, block in blocks:
        text = _clean(block.get("text", block.get("content", "")))
        if not text:
            continue
        for field, aliases in FIELD_ALIASES.items():
            if field in fields or field in {"owner_name", "relative_name", "relation", "village", "district", "police_station"}:
                continue
            value = _label_value(text, aliases)
            if not value:
                continue

            if field in _NUMBER_FIELDS:
                value = _extract_number(value)
                if not value:
                    continue
                extraction_conf = 0.90
            elif field == "area":
                number, unit = _extract_area(value)
                if not number:
                    continue
                value = {"value": number, "unit": unit}
                extraction_conf = 0.90
            else:
                extraction_conf = 0.82

            fields[field] = _make_field(
                value, page_no, block=block, source="text_block",
                extraction_confidence=extraction_conf, evidence_text=text,
            )

    # 4) Structured Mistral markdown tables. These override generic text values
    # for numeric land identifiers because the column semantics are explicit.
    for page_no, table, block in _page_tables(pages):
        found = _extract_table_fields(page_no, table, block)
        for key, value in found.items():
            fields[key] = value

    return fields


__all__ = ["extract_fields"]
